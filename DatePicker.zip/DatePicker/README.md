
1
import CalendarSinglePickerModal, {open} from '../../component/datePicker/CalendarSinglePickerModal';

2
<CalendarSinglePickerModal
ref={(node) => {
this.calendarRefs = node
}}
rangeSelect={false} // false 单选  true 多选
submitFunc={(startTime, endTime) => {
console.log(startTime)
//选择时间
if (startTime) {
this.salesOrderStore.getCurrentTime(startTime)
}
}}
/>

3
 this.calendarRefs.open();
 
 4
 
 附件截图
 
 这个地方改成你自己需要的颜色 


P.S: 有问题群里找:582325158
