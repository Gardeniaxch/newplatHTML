
'use strict';
import React, { Component } from 'react';
import {
    View,
    Modal,
    TouchableOpacity,
    Platform,
    StatusBar,
    Text,
    StyleSheet
} from 'react-native';
import Constant from "../../common/constants";
import { PropTypes } from 'prop-types';
import moment from 'moment';
import Calendar from './calendarPicker/Calendar';

//基于calendarPicker 单选的modal 
export default class CalendarSinglePickerModal extends Component {
    static propTypes = {
        hiddenDatePicker: PropTypes.func
    }

    // 构造
    constructor(props) {
        super(props);
        // 初始状态
        this.state = {
            modalVisible: false,
            selectIndex: 0,
            startTime: '',
            endTime: '',
            isConfirmClick: false
        };
        this._bindMyFunc();
    }

    //方法绑定
    _bindMyFunc() {
    }

    render() {
        let { submitFunc } = this.props;
        let { modalVisible } = this.state;
        let modalStatusBar = Platform.OS === "android" &&
            <StatusBar translucent={true}
                backgroundColor="#0C093A9c"
                barStyle='light-content' />

        let calendarView =
            <Calendar
                monthsCount={200}
                startFormMonday={true}
                enabledToday={true}
                startDate={new Date()}
                selectFrom={null}
                selectTo={null}
                onDateChange={(selectFrom, selectTo) => {
                    let startTime = moment(selectFrom).format("YYYY-MM-DD")
                    let endTime = moment(selectTo).format("YYYY-MM-DD")
                    if (this.props.rangeSelect && startTime != 'Invalid date' && endTime != 'Invalid date') {
                        this.setState({ startTime, endTime })
                    } else {
                        this.setState({ startTime, endTime: '' })
                    }
                }}
                monthsLocale={['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']}
                bodyTextColor={Constant.colors.textClr}
                monthTextColor={Constant.colors.textClr}
                daySelectedBackColor={Constant.colors.themeColor}
                dayInRangeBackColor={'#98C7FF'}
                rangeSelect={this.props.rangeSelect}
            />
        let confirmBackgroundColor = '';
        let confirmTextColor = '';

        if (!this.props.rangeSelect) {
            confirmBackgroundColor = "#3E53FF";
            confirmTextColor = 'white';
        } else {
            if (this.props.rangeSelect && this.state.startTime != '' && this.state.endTime != '') {
                confirmBackgroundColor = "#3E53FF";
                confirmTextColor = 'white';
            } else {
                confirmBackgroundColor = '#D2D5E2';
                confirmTextColor = "#302F3B";
            }
        }
        return (
            modalVisible &&
            <View style={{
                position: 'absolute', backgroundColor: '#0C093A9c',
                width: '100%', height: '100%',
                zIndex: 10000, elevation: 2,
            }}>
                {modalStatusBar}
                <Modal transparent={true} visible={modalVisible} animationType={"none"}>
                    <View style={{
                        position: 'absolute', width: '100%', height: '100%',
                        zIndex: 2, elevation: 2,
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <View style={[styles.center, {
                            backgroundColor: 'white',
                            height: "60%",
                            borderRadius: 8,
                        }]}>
                            <View style={{ height: 40, justifyContent: 'center', alignItems: 'center' }}>
                                <Text style={{ color: "#302F3B", fontSize: 18 }}>选择日期</Text>
                            </View>
                            {calendarView}
                            <View style={[styles.center, { height: 70, flexDirection: 'row' }]}>
                                <TouchableOpacity
                                    style={[styles.center, {
                                        borderRadius: 32,
                                        width: 100,
                                        height: 30,
                                        backgroundColor: '#D2D5E2'
                                    }]}
                                    activeOpacity={1}
                                    onPress={() => this.close()}
                                >
                                    <Text style={{ fontSize: 14, color: "#302F3B" }}>取消</Text>
                                </TouchableOpacity>
                                <TouchableOpacity
                                    style={[styles.center, {
                                        marginLeft: 10,
                                        borderRadius: 32,
                                        width: 100,
                                        height: 30,
                                        backgroundColor: confirmBackgroundColor
                                    }]}
                                    activeOpacity={1}
                                    onPress={() => {
                                        if (!this.props.rangeSelect) {
                                            this.close()
                                            submitFunc(
                                                this.state.startTime, this.state.endTime
                                            )
                                        } else {
                                            if (this.props.rangeSelect && this.state.startTime != '' && this.state.endTime != '') {
                                                this.close()
                                                submitFunc(
                                                    this.state.startTime, this.state.endTime
                                                )
                                            } else {
                                                return;
                                            }
                                        }
                                    }}
                                >
                                    <Text style={{ fontSize: 14, color: confirmTextColor }}>确认</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </Modal>
            </View>
        )
    }

    close() {
        this.setState({ modalVisible: false });
    }

    open() {
        this.setState({ modalVisible: true });
    }

}


const styles = StyleSheet.create({
    center: {
        alignItems: 'center',
        justifyContent: 'center'
    },


})