'use strict';

import React from 'react';
import {
	View,
	StyleSheet,
	Text,
	Dimensions
} from 'react-native';
import Day from './Day'

export default class Month extends React.Component {
	constructor(props) {
		super(props);

		this.weekDaysLocale = props.weekDaysLocale.slice();

		if (props.startFromMonday) {
			this.weekDaysLocale.push(this.weekDaysLocale.shift());
		}
	}

	render() {
		let {
			days, changeSelection, style, monthsLocale,
			bodyBackColor, bodyTextColor, headerSepColor, width, monthTextColor
		} = this.props;
		var monthHeader = days[15].date.getFullYear() + '年' + monthsLocale[days[15].date.getMonth()] + '月';

		return (
			<View style={[style, { width: width, backgroundColor: bodyBackColor }]}>
				<Text allowFontScaling={false} style={[styles.monthHeader, { color: monthTextColor || bodyTextColor }]}>
					{monthHeader}
				</Text>
				<View style={styles.monthDays}>
					{days.map((day, i) => {

						let month = days[days.length - 1].date.getMonth();
						let dayModule;
						if (day.date.getMonth() != month) {
							dayModule = (
								<Day
									key={i}
									{...this.props}
									disabled={''}
									status={''}
									date={''}
									onDayPress={() => { }}
								/>
							)
						} else {

							dayModule = (
								<Day
									key={i}
									{...this.props}
									disabled={day.disabled}
									status={day.status}
									date={day.date}
									onDayPress={changeSelection}
								/>
							)
						}
						return (
							dayModule
						);
					})}
				</View>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	monthHeader: {
		marginTop: 15,
		marginBottom: 5,
		alignSelf: 'center',
		backgroundColor: '#f6f6f6',
		width: Dimensions.get('window').width,
		textAlign: 'center',
		paddingTop: 4,
		paddingBottom: 4
	},
	monthDays: {
		flexDirection: 'row',
		flexWrap: 'wrap',
		flex: 1
	},
	weekDay: {
		borderBottomWidth: 1,
		justifyContent: 'center',
		alignItems: 'center'
	}
});
