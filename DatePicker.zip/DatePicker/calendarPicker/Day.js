'use strict';

import React from 'react';
import {
	StyleSheet,
	TouchableOpacity,
	Text
} from 'react-native';
import LunarCalendar from './LunarCalendar'

export default class Day extends React.Component {
	render() {
		let { date, status, disabled, onDayPress, width } = this.props;
		let onPress, textColor, backColor;

		if (disabled) {
			status = 'disabled';
			onPress = null;
		} else {
			onPress = () => {
				onDayPress(date);
			}
		}

		let holiday = this.getHoliday(date);

		switch (status) {
			case 'disabled':
				backColor = this.props.dayDisabledBackColor;
				textColor = this.props.dayDisabledTextColor;
				break;

			case 'common':
				backColor = this.props.dayCommonBackColor;
				textColor = this.props.dayCommonTextColor;
				if(holiday){
					//周六周日变成红色
                    textColor = '#378CF1';
				}
				break;

			case 'selected':
				backColor = this.props.daySelectedBackColor;
				textColor = this.props.daySelectedTextColor;
				break;

			case 'inRange':
				backColor = this.props.dayInRangeBackColor;
				textColor = this.props.dayInRangeTextColor;
				break;
		}
		let todayDate = new Date().Format("yyyy-MM-dd");
		let time = Date.parse(date);
		let formatDate = new Date(time).Format("yyyy-MM-dd");
		let day;
		if (formatDate == todayDate) {
			day = "今天";
		} else {
            if(date) {
                if(holiday){
					day = holiday;
				}else {
					day = date.getDate();
				}
            }else{
                day ='';
			}
			// day = date ? date.getDate() : '';
		}
		return (
			<TouchableOpacity
				activeOpacity={disabled ? 1 : 0.5}
				style={[styles.common, { backgroundColor: backColor, width: parseInt(width / 7), height: parseInt(width / 7) }]}
				onPress={onPress}>
				<Text allowFontScaling={false} style={{ color: textColor, }}>{day}</Text>
			</TouchableOpacity>
		);
	}

	getHoliday(date){
		let holidayStr ="";
        if(date) {
            let lunar = LunarCalendar.solarToLunar(date.getFullYear(),date.getMonth()+1,date.getDate());
            let lunarFestival = lunar.lunarFestival;//农历节日
            let solarFestival = lunar.solarFestival;//公历节日
            let term = lunar.term;//节气
            if(lunarFestival){
                holidayStr = lunarFestival;
            }else if(solarFestival){
                holidayStr = solarFestival;
            }else if(term){
            	if(term ==='清明'){
                	holidayStr = term;
                }
            }
            // day = Lunar.toLunar(date.getFullYear(), date.getMonth() - 1, date.getDate());
        }
        return holidayStr;
	}
}

const styles = StyleSheet.create({
	common: {
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: 'white',
	}
});